/**
 * Mero Miti - Today's Nepali Date Widget Embed Script
 * https://meromiti.com
 *
 * Usage:
 * <div class="meromiti-widget" data-lang="ne" data-theme="auto" data-layout="standard"></div>
 * <script src="https://meromiti.com/widget.js" async></script>
 */
(function () {
  'use strict';

  var BASE_URL = (function () {
    var scripts = document.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].src || '';
      if (src.indexOf('widget.js') !== -1) {
        var a = document.createElement('a');
        a.href = src;
        return a.protocol + '//' + a.host;
      }
    }
    return 'https://meromiti.com';
  })();

  var HEIGHTS = {
    standard: 155,
    compact: 105,
    minimal: 100,
    pill: 72,
    month: 410,
  };

  function initWidgets() {
    var elements = document.querySelectorAll(
      '.meromiti-widget, [data-meromiti-widget], [data-mero-miti-widget], #meromiti-today-widget'
    );

    for (var i = 0; i < elements.length; i++) {
      var el = elements[i];
      if (el.getAttribute('data-meromiti-loaded') === 'true') {
        continue;
      }

      var type = el.getAttribute('data-type') || '';
      var lang = el.getAttribute('data-lang') || 'ne';
      var theme = el.getAttribute('data-theme') || 'auto';
      var layout = el.getAttribute('data-layout') || 'standard';
      var bg = el.getAttribute('data-bg') || 'card';
      var border = el.getAttribute('data-border') || '1';
      var branding = el.getAttribute('data-branding') || '1';
      var color = el.getAttribute('data-color') || '';

      var isMonthWidget = type === 'month' || layout === 'month';

      var queryParams = [
        'lang=' + encodeURIComponent(lang),
        'theme=' + encodeURIComponent(theme),
        'bg=' + encodeURIComponent(bg),
        'border=' + encodeURIComponent(border),
        'branding=' + encodeURIComponent(branding),
      ];

      if (!isMonthWidget) {
        queryParams.push('layout=' + encodeURIComponent(layout));
      }

      if (color) {
        queryParams.push('color=' + encodeURIComponent(color));
      }

      var endpoint = isMonthWidget ? '/widget/month' : '/widget/today';
      var iframeUrl = BASE_URL + endpoint + '?' + queryParams.join('&');
      var expectedHeight = isMonthWidget ? 410 : (HEIGHTS[layout] || 155);
      var maxWidth = isMonthWidget ? '460px' : (layout === 'pill' ? '280px' : layout === 'minimal' ? '320px' : '420px');

      var iframe = document.createElement('iframe');
      iframe.src = iframeUrl;
      iframe.title = isMonthWidget ? "Nepali Month Calendar Widget - Mero Miti" : "Today's Nepali Date Widget - Mero Miti";
      iframe.style.width = '100%';
      iframe.style.maxWidth = maxWidth;
      iframe.style.height = expectedHeight + 'px';
      iframe.style.border = 'none';
      iframe.style.overflow = 'hidden';
      iframe.style.background = 'transparent';
      iframe.style.display = 'block';
      iframe.setAttribute('scrolling', 'no');
      iframe.setAttribute('frameBorder', '0');
      iframe.setAttribute('loading', 'lazy');

      el.innerHTML = '';
      el.appendChild(iframe);

      // Little style change after load
      iframe.onload = function () {
          var doc = iframe.contentDocument || iframe.contentWindow.document;
          var style = doc.createElement('style');
          style.textContent = `
              .meromiti-month-widget {
                  padding:0 !important;
              }
          `;
          doc.head.appendChild(style);
      };
      // End style change after load
      
      el.setAttribute('data-meromiti-loaded', 'true');
    }
  }

  // Dynamic iframe auto-resize listener
  window.addEventListener('message', function (event) {
    if (event.data && event.data.type === 'meromiti-widget-resize' && typeof event.data.height === 'number') {
      var iframes = document.querySelectorAll('iframe[src*="/widget/"]');
      for (var i = 0; i < iframes.length; i++) {
        if (iframes[i].contentWindow === event.source) {
          iframes[i].style.height = event.data.height + 'px';
        }
      }
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWidgets);
  } else {
    initWidgets();
  }

  // Global namespace for manual re-init
  window.MeroMitiWidget = {
    init: initWidgets,
    version: '1.1.0',
  };
})();
